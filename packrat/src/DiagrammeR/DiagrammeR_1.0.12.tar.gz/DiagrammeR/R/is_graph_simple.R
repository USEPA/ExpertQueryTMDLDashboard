#' Is the graph a simple graph?
#'
#' @description
#'
#' Determine whether the graph is a simple graph. A simple graph is one that
#' does not contain any loops nor any multiple edges.
#'
#' @inheritParams render_graph
#'
#' @return A logical value.
#'
#' @examples
#' # Create a graph with 2 cycles
#' graph <-
#'   create_graph() |>
#'   add_cycle(n = 4) |>
#'   add_cycle(n = 3)
#'
#' # Check if the graph is simple
#' graph |> is_graph_simple()
#'
#' @export
is_graph_simple <- function(graph) {

  # Validation: Graph object is valid
  check_graph_valid(graph)

  # Convert the graph to an igraph object
  ig_graph <- to_igraph(graph)

  # Determine whether the graph is
  # a simple graph
  igraph::is_simple(ig_graph)
}
